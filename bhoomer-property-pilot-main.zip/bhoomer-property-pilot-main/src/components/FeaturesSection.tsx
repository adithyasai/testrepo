
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Home, MapPin, Search } from "lucide-react";

const features = [
  {
    title: "Effortless Searching",
    description: "Easily find your dream property with our smart filters and intuitive search features",
    icon: Search,
  },
  {
    title: "Guided Property Visits",
    description: "Schedule visits with expert agents who guide you through every property",
    icon: MapPin,
  },
  {
    title: "Convenient Transportation",
    description: "Book cab services directly through the platform for seamless property visits",
    icon: Home,
  },
  {
    title: "Flexible Scheduling",
    description: "Choose time frames that work for you with our easy booking system",
    icon: Calendar,
  },
];

const FeaturesSection: React.FC = () => {
  return (
    <section className="py-16 px-6 md:px-10">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-bhoomer-primary mb-4">
            Why Choose Bhoomer?
          </h2>
          <p className="text-gray-600 md:max-w-2xl mx-auto">
            We're revolutionizing the way you search for properties with our innovative features and services
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="bg-bhoomer-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-bhoomer-primary" />
                </div>
                <CardTitle className="text-xl text-bhoomer-primary">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
