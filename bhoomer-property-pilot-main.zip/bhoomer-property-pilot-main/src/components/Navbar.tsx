
import React from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Navbar: React.FC = () => {
  const scrollToHero = () => {
    const heroSection = document.getElementById('hero-section');
    if (heroSection) {
      heroSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="bg-white py-6 px-6 md:px-10 shadow-sm">
      <div className="container mx-auto flex justify-between items-center">
        <div>
          <Button variant="ghost" onClick={scrollToHero} className="text-lg font-medium">
            Home
          </Button>
        </div>
        <div>
          <Button variant="ghost" asChild className="text-lg font-medium">
            <a 
              href="https://www.instagram.com/bhoomerindia?igsh=MTRoZWE5eGNtM3lmZw==" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              Contact
            </a>
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
