
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    quote: "Bhoomer made finding my dream home so much easier. The cab booking feature saved me hours of travel time!",
    author: "Priya Sharma",
    role: "Homeowner",
    avatar: "https://randomuser.me/api/portraits/women/32.jpg",
  },
  {
    quote: "As a real estate investor, I need to view multiple properties quickly. Bhoomer's platform streamlined the entire process.",
    author: "Vikram Singh",
    role: "Property Investor",
    avatar: "https://randomuser.me/api/portraits/men/44.jpg",
  },
  {
    quote: "I was hesitant at first, but the guided visits with knowledgeable agents made all the difference in my property search.",
    author: "Aisha Patel",
    role: "First-time Buyer",
    avatar: "https://randomuser.me/api/portraits/women/68.jpg",
  },
];

const TestimonialSection: React.FC = () => {
  return (
    <section className="py-16 px-6 md:px-10 bg-gray-50">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-bhoomer-primary mb-4">
            What Our Users Say
          </h2>
          <p className="text-gray-600 md:max-w-2xl mx-auto">
            Hear from people who've experienced the Bhoomer difference
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white border-none shadow-md">
              <CardContent className="pt-6 px-6 pb-6">
                <div className="flex flex-col items-center mb-4 text-center">
                  <div className="w-16 h-16 rounded-full overflow-hidden mb-4 border-2 border-bhoomer-secondary">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.author}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="font-semibold text-lg">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
                <p className="text-gray-600 italic">"{testimonial.quote}"</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;
