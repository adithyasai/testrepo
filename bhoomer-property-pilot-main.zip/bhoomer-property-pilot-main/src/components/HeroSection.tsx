
import React from "react";
import { Button } from "@/components/ui/button";
import WaitlistOptionsDialog from "@/components/WaitlistOptionsDialog";
import Logo from "./Logo";

const HeroSection: React.FC = () => {
  return (
    <section id="hero-section" className="bg-gradient-to-br from-white to-blue-50 py-20 px-6 md:px-10">
      <div className="container mx-auto">
        <div className="max-w-2xl mx-auto text-center space-y-6">
          <div className="flex justify-center mb-6">
            <Logo className="mx-auto scale-110" />
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold">
            <span style={{ color: "#1bb736" }}>Defining</span>
            <br />
            <span style={{ color: "#4682B4" }}>Experience Real Estate</span>
          </h1>
          <p className="text-lg md:text-xl text-[#444444]">
            First Stop : HYDERABAD - Launching Soon
          </p>
          <div className="pt-4">
            <WaitlistOptionsDialog
              trigger={
                <Button size="lg" className="text-md">
                  Privilege List
                </Button>
              }
            />
            <p className="mt-3 text-sm text-[#444444]">
              Join our privilege list to be among the first to experience Bhoomer
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
