
import React from "react";

const CTASection: React.FC = () => {
  return (
    <section className="py-16 px-6 md:px-10 bg-blue-50">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6 text-bhoomer-primary">
          What is Bhoomer?
        </h2>
        <p className="md:max-w-2xl mx-auto text-lg mb-8 text-[#444444]">
          Bhoomer is an on-demand platform for effortless real estate scouting. From renting to buying your dream home or land, 
          we simplify the process with convenience, networking, and a seamless experience.
        </p>
      </div>
    </section>
  );
};

export default CTASection;
