
import React from "react";
import { Link } from "react-router-dom";
import { Instagram } from "lucide-react";
import WaitlistOptionsDialog from "@/components/WaitlistOptionsDialog";

const Footer: React.FC = () => {
  const scrollToHero = () => {
    const heroSection = document.getElementById('hero-section');
    if (heroSection) {
      heroSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-bhoomer-light py-10 px-6 md:px-10 border-t">
      <div className="container mx-auto">
        <div className="flex justify-between">
          <div className="flex flex-col items-start">
            <h3 className="font-semibold mb-3">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button 
                  onClick={scrollToHero}
                  className="text-gray-600 hover:text-bhoomer-primary text-left"
                >
                  Home
                </button>
              </li>
              <li>
                <WaitlistOptionsDialogSimple 
                  trigger={<button className="text-gray-600 hover:text-bhoomer-primary text-left">Privilege List</button>} 
                />
              </li>
            </ul>
          </div>
          
          <div className="flex flex-col items-end">
            <h3 className="font-semibold mb-3">Contact</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="https://www.instagram.com/bhoomerindia?igsh=MTRoZWE5eGNtM3lmZw==" 
                  target="_blank"
                  rel="noopener noreferrer" 
                  className="flex items-center gap-2 text-gray-600 hover:text-bhoomer-primary"
                >
                  <Instagram size={16} />
                  <span>@bhoomerindia</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-10 pt-5 border-t border-gray-200 text-center text-sm text-gray-600">
          <p>© {new Date().getFullYear()} Bhoomer Digital Solutions Pvt Ltd</p>
        </div>
      </div>
    </footer>
  );
};

// Simple wrapper for the WaitlistOptionsDialog to use in the footer
const WaitlistOptionsDialogSimple: React.FC<{ trigger: React.ReactNode }> = ({ trigger }) => {
  const WaitlistOptionsDialog = React.lazy(() => 
    import('@/components/WaitlistOptionsDialog')
  );

  return (
    <React.Suspense fallback={<div>{trigger}</div>}>
      <WaitlistOptionsDialog trigger={trigger} />
    </React.Suspense>
  );
};

export default Footer;
