
import React from "react";

const steps = [
  {
    number: "01",
    title: "Join Waitlist",
    description: "Sign up for our waitlist and provide your property preferences",
  },
  {
    number: "02",
    title: "Get Notified",
    description: "Receive early access when Bhoomer launches",
  },
  {
    number: "03",
    title: "Book Visits",
    description: "Schedule property visits with cab services included",
  },
  {
    number: "04",
    title: "Find Your Dream Home",
    description: "Get expert guidance to secure your perfect property",
  },
];

const HowItWorksSection: React.FC = () => {
  return (
    <section className="py-16 px-6 md:px-10">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-bhoomer-primary mb-4">
            How It Works
          </h2>
          <p className="text-gray-600 md:max-w-2xl mx-auto">
            Bhoomer makes property scouting simple and convenient
          </p>
        </div>

        <div className="relative">
          <div className="absolute left-[50%] h-full w-0.5 bg-bhoomer-secondary/30 hidden md:block"></div>
          
          <div className="space-y-12 relative">
            {steps.map((step, index) => (
              <div key={index} className="md:grid md:grid-cols-2 md:gap-8 items-center">
                <div className={`mb-6 md:mb-0 ${index % 2 !== 0 ? "md:order-2" : ""}`}>
                  <div className="bg-bhoomer-light rounded-lg p-8 shadow-md relative">
                    <div className="absolute -left-4 top-1/2 transform -translate-y-1/2 bg-bhoomer-secondary text-white text-xl font-bold w-8 h-8 rounded-full flex items-center justify-center md:hidden">
                      {step.number}
                    </div>
                    <h3 className="text-xl font-semibold text-bhoomer-primary mb-2">{step.title}</h3>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                </div>
                
                <div className={`hidden md:flex ${index % 2 !== 0 ? "justify-start" : "justify-end"}`}>
                  <div className="w-16 h-16 bg-bhoomer-secondary rounded-full flex items-center justify-center text-white font-bold text-xl relative z-10">
                    {step.number}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
