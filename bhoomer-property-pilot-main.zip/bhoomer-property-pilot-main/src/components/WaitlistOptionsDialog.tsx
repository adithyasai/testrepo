import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink, User, Home, Building2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface WaitlistDialogProps {
  trigger: React.ReactNode;
  className?: string;
}

type PropertyOwnerData = {
  name: string;
  email: string;
  mobile: string;
  propertyLocation: string;
};

type AgentData = {
  name: string;
  email: string;
  mobile: string;
  operationArea: string;
};

const WaitlistOptionsDialog: React.FC<WaitlistDialogProps> = ({
  trigger,
  className,
}) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const propertyOwnerForm = useForm({
    defaultValues: {
      name: "",
      email: "",
      mobile: "",
      propertyLocation: "",
    }
  });

  const agentForm = useForm({
    defaultValues: {
      name: "",
      email: "",
      mobile: "",
      operationArea: "",
    }
  });

  const handlePropertyOwnerSubmit = async (data: PropertyOwnerData) => {
    setIsSubmitting(true);
    try {
      console.log("Property Owner form submitted:", data);
      
      toast({
        title: "Submission Successful",
        description: "Your information has been saved to our database.",
      });
      setFormSubmitted(true);
    } catch (error) {
      console.error("Error submitting property owner form:", error);
      toast({
        title: "Submission Failed",
        description: "There was an error saving your information. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAgentSubmit = async (data: AgentData) => {
    setIsSubmitting(true);
    try {
      console.log("Real Estate Agent form submitted:", data);
      
      toast({
        title: "Submission Successful",
        description: "Your information has been saved to our database.",
      });
      setFormSubmitted(true);
    } catch (error) {
      console.error("Error submitting agent form:", error);
      toast({
        title: "Submission Failed",
        description: "There was an error saving your information. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetDialogState = () => {
    setSelectedOption(null);
    setFormSubmitted(false);
    propertyOwnerForm.reset();
    agentForm.reset();
  };

  const mainColor = "#4682B4";

  const options = [
    {
      id: "propertyOwner",
      title: "Property Owner",
      description: "List and manage your properties with Bhoomer",
      icon: <Home className="h-5 w-5 text-white" />,
      color: "white",
      textColor: "#000",
    },
    {
      id: "seeker",
      title: "Property Seeker",
      description: "Find your ideal property with our advanced search tools",
      link: "https://docs.google.com/forms/d/e/1FAIpQLSfIsSWWq0dVJH1_bctLTijAnKAivCrODPUNb10P9StW3aCGVA/viewform?usp=dialog",
      icon: <Building2 className="h-5 w-5 text-white" />,
      color: mainColor,
      textColor: "white",
    },
    {
      id: "agent",
      title: "Real Estate Agent",
      description: "Connect with clients and grow your business",
      icon: <User className="h-5 w-5 text-white" />,
      color: "white",
      textColor: "#000",
    },
  ];

  const renderForm = () => {
    if (formSubmitted) {
      return (
        <div className="text-center py-10">
          <h3 className="text-xl font-semibold mb-4">Thank You!</h3>
          <p className="text-gray-600 mb-6">Your submission has been received. We'll be in touch soon.</p>
          <Button onClick={resetDialogState}>Close</Button>
        </div>
      );
    }

    switch (selectedOption) {
      case "propertyOwner":
        return (
          <Form {...propertyOwnerForm}>
            <form onSubmit={propertyOwnerForm.handleSubmit(handlePropertyOwnerSubmit)} className="space-y-4">
              <FormField
                control={propertyOwnerForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Owner Name</FormLabel>
                    <FormControl>
                      <Input required placeholder="Enter your full name" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={propertyOwnerForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email ID</FormLabel>
                    <FormControl>
                      <Input required type="email" placeholder="Enter your email" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={propertyOwnerForm.control}
                name="mobile"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile Number</FormLabel>
                    <FormControl>
                      <Input required placeholder="Enter your mobile number" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={propertyOwnerForm.control}
                name="propertyLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location of the Property</FormLabel>
                    <FormControl>
                      <Textarea required placeholder="Enter property location details" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="pt-4 flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setSelectedOption(null)}>Back</Button>
                <Button type="submit" style={{ backgroundColor: mainColor }} disabled={isSubmitting}>
                  {isSubmitting ? "Submitting..." : "Submit"}
                </Button>
              </div>
            </form>
          </Form>
        );
      case "agent":
        return (
          <Form {...agentForm}>
            <form onSubmit={agentForm.handleSubmit(handleAgentSubmit)} className="space-y-4">
              <FormField
                control={agentForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input required placeholder="Enter your full name" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={agentForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email ID</FormLabel>
                    <FormControl>
                      <Input required type="email" placeholder="Enter your email" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={agentForm.control}
                name="mobile"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile Number</FormLabel>
                    <FormControl>
                      <Input required placeholder="Enter your mobile number" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={agentForm.control}
                name="operationArea"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Area of Operation in Hyderabad/Telangana</FormLabel>
                    <FormControl>
                      <Textarea required placeholder="Enter your area of operation" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="pt-4 flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setSelectedOption(null)}>Back</Button>
                <Button type="submit" style={{ backgroundColor: mainColor }} disabled={isSubmitting}>
                  {isSubmitting ? "Submitting..." : "Submit"}
                </Button>
              </div>
            </form>
          </Form>
        );
      default:
        return (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-4">
            {options.map((option) => (
              option.id === "seeker" ? (
                <a 
                  key={option.id}
                  href={option.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="no-underline"
                >
                  <Card 
                    className="cursor-pointer transition-all hover:shadow-lg h-full"
                    style={{ 
                      backgroundColor: option.color,
                      color: option.textColor
                    }}
                  >
                    <CardContent className="flex flex-col items-center justify-center p-6 text-center h-full">
                      <div className="flex-grow flex flex-col items-center justify-center">
                        <div 
                          className="w-12 h-12 rounded-full mb-3 flex items-center justify-center"
                          style={{ backgroundColor: mainColor }}
                        >
                          {option.icon}
                        </div>
                        <h3 className="font-semibold text-lg mb-2">{option.title}</h3>
                        <p className="text-sm" style={{ color: option.textColor === "#000" ? "#666" : "rgba(255,255,255,0.8)" }}>{option.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                </a>
              ) : (
                <Card 
                  key={option.id}
                  onClick={() => setSelectedOption(option.id)}
                  className="cursor-pointer transition-all hover:shadow-lg h-full"
                  style={{ 
                    backgroundColor: option.color,
                    color: option.textColor
                  }}
                >
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center h-full">
                    <div className="flex-grow flex flex-col items-center justify-center">
                      <div 
                        className="w-12 h-12 rounded-full mb-3 flex items-center justify-center"
                        style={{ backgroundColor: mainColor }}
                      >
                        {option.icon}
                      </div>
                      <h3 className="font-semibold text-lg mb-2">{option.title}</h3>
                      <p className="text-sm" style={{ color: option.textColor === "#000" ? "#666" : "rgba(255,255,255,0.8)" }}>{option.description}</p>
                    </div>
                  </CardContent>
                </Card>
              )
            ))}
          </div>
        );
    }
  };

  return (
    <Dialog onOpenChange={(open) => { if (!open) resetDialogState(); }}>
      <DialogTrigger asChild>
        {trigger}
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {selectedOption ? 
              (selectedOption === "propertyOwner" ? "Property Owner Details" : 
               selectedOption === "agent" ? "Real Estate Agent Details" : 
               "Choose an option") : 
              "Choose an option to join our privilege list"}
          </DialogTitle>
          <DialogDescription>
            {selectedOption ? 
              "Please complete the form below" : 
              "Select the option that best describes your real estate needs"}
          </DialogDescription>
        </DialogHeader>
        {renderForm()}
      </DialogContent>
    </Dialog>
  );
};

export default WaitlistOptionsDialog;
