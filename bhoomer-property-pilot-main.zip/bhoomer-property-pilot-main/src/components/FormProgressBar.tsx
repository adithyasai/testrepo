
import React from "react";

interface FormProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

const FormProgressBar: React.FC<FormProgressBarProps> = ({
  currentStep,
  totalSteps,
}) => {
  const progress = (currentStep / totalSteps) * 100;

  return (
    <div className="w-full">
      <div className="flex justify-between mb-2">
        <span className="text-sm font-medium text-bhoomer-primary">
          Step {currentStep} of {totalSteps}
        </span>
        <span className="text-sm font-medium text-bhoomer-primary">
          {Math.round(progress)}%
        </span>
      </div>
      <div className="w-full h-2 bg-gray-200 rounded-full">
        <div
          className="h-2 bg-bhoomer-secondary rounded-full transition-all duration-300 ease-in-out"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
    </div>
  );
};

export default FormProgressBar;
