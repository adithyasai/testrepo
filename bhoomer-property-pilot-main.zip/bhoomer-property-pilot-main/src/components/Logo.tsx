
import React from "react";

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "" }) => {
  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src="/lovable-uploads/6449274e-1036-4bc0-b0e0-6f44083e397c.png" 
        alt="Bhoomer Logo" 
        className="h-24 md:h-28" // Increased size further
      />
    </div>
  );
};

export default Logo;
