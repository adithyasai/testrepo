import React, { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import FormProgressBar from "@/components/FormProgressBar";
import { InputField, RadioGroupField, SelectField, CheckboxField } from "@/components/FormInputs";
import { useToast } from "@/hooks/use-toast";
import { Link, useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";

const WaitlistForm = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const totalSteps = 3;

  // User details form (step 1)
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  // Questions form (step 2)
  const [ageGroup, setAgeGroup] = useState("");
  const [incomeSource, setIncomeSource] = useState("");
  const [livesInHyderabad, setLivesInHyderabad] = useState("");
  const [currentLocation, setCurrentLocation] = useState("");
  const [moveTime, setMoveTime] = useState("");
  const [propertyType, setPropertyType] = useState("");
  const [checkoutFrequency, setCheckoutFrequency] = useState("");

  // Additional questions form (step 3)
  const [nextMove, setNextMove] = useState("");
  const [propertyLooking, setPropertyLooking] = useState("");
  const [rentBudget, setRentBudget] = useState("");
  const [purchaseBudget, setPurchaseBudget] = useState("");
  const [searchDuration, setSearchDuration] = useState("");
  const [weeklyVisits, setWeeklyVisits] = useState("");
  const [researchTime, setResearchTime] = useState("");
  const [transportMode, setTransportMode] = useState("");
  const [travelTime, setTravelTime] = useState("");
  const [weeklySpend, setWeeklySpend] = useState("");
  const [satisfaction, setSatisfaction] = useState("");

  // Form validation
  const validateStep1 = () => {
    if (!firstName.trim()) {
      toast({
        title: "First name is required",
        variant: "destructive",
      });
      return false;
    }
    if (!lastName.trim()) {
      toast({
        title: "Last name is required",
        variant: "destructive",
      });
      return false;
    }
    if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
      toast({
        title: "Valid email is required",
        variant: "destructive",
      });
      return false;
    }
    if (!phone.trim() || phone.length < 10) {
      toast({
        title: "Valid phone number is required",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (!ageGroup) {
      toast({
        title: "Please select your age group",
        variant: "destructive",
      });
      return false;
    }
    if (!incomeSource) {
      toast({
        title: "Please select your income source",
        variant: "destructive",
      });
      return false;
    }
    if (!livesInHyderabad) {
      toast({
        title: "Please indicate if you live in Hyderabad",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    if (!nextMove) {
      toast({
        title: "Please select your next move",
        variant: "destructive",
      });
      return false;
    }
    if (!propertyLooking) {
      toast({
        title: "Please select property type you're looking for",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  // Handle form navigation
  const nextStep = () => {
    if (step === 1 && !validateStep1()) return;
    if (step === 2 && !validateStep2()) return;
    if (step === 3 && !validateStep3()) {
      handleSubmit();
      return;
    }
    if (step < totalSteps) {
      setStep(step + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
      window.scrollTo(0, 0);
    }
  };

  const handleSubmit = () => {
    // In a real app, you'd submit the form data to your backend here
    console.log({
      firstName,
      lastName,
      email,
      phone,
      ageGroup,
      incomeSource,
      livesInHyderabad,
      currentLocation,
      moveTime,
      propertyType,
      checkoutFrequency,
      nextMove,
      propertyLooking,
      rentBudget,
      purchaseBudget,
      searchDuration,
      weeklyVisits,
      researchTime,
      transportMode,
      travelTime,
      weeklySpend,
      satisfaction,
    });
    
    toast({
      title: "Waitlist Submission Successful!",
      description: "Thank you for joining the Bhoomer waitlist. Check your email for confirmation.",
    });
    
    navigate("/booking");
  };

  // Render form steps
  const renderFormStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold mb-6">Your Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InputField
                label="First Name"
                type="text"
                id="firstName"
                placeholder="John"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
              />
              <InputField
                label="Last Name"
                type="text"
                id="lastName"
                placeholder="Doe"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
              />
            </div>
            <InputField
              label="Email"
              type="email"
              id="email"
              placeholder="john.doe@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <InputField
              label="Phone Number"
              type="tel"
              id="phone"
              placeholder="9876543210"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </div>
        );
      case 2:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold mb-6">About You</h2>
            <RadioGroupField
              label="What is your age group?"
              id="ageGroup"
              options={[
                { value: "28-32", label: "28-32" },
                { value: "33-37", label: "33-37" },
                { value: "38-42", label: "38-42" },
                { value: "43-45", label: "43-45" },
                { value: "other", label: "Other" },
              ]}
              value={ageGroup}
              onChange={setAgeGroup}
              required
            />
            <RadioGroupField
              label="What is your source of Income?"
              id="incomeSource"
              options={[
                { value: "employee", label: "Employee (Private or Govt)" },
                { value: "selfEmployed", label: "Self Employed or Freelancer" },
                { value: "businessOwner", label: "Business Owner" },
                { value: "other", label: "Other" },
              ]}
              value={incomeSource}
              onChange={setIncomeSource}
              required
            />
            <RadioGroupField
              label="Are you currently residing in Hyderabad?"
              id="livesInHyderabad"
              options={[
                { value: "yes", label: "Yes" },
                { value: "no", label: "No" },
              ]}
              value={livesInHyderabad}
              onChange={setLivesInHyderabad}
              required
            />
            {livesInHyderabad && (
              <InputField
                label={livesInHyderabad === "yes" ? "Mention the area" : "Mention your current location"}
                type="text"
                id="currentLocation"
                placeholder={livesInHyderabad === "yes" ? "e.g., Banjara Hills" : "e.g., Bangalore"}
                value={currentLocation}
                onChange={(e) => setCurrentLocation(e.target.value)}
              />
            )}
            <RadioGroupField
              label="When did you move into your current house?"
              id="moveTime"
              options={[
                { value: "lessThan1", label: "Less than 1 year ago" },
                { value: "1-3", label: "1-3 years" },
                { value: "3-5", label: "3-5 years" },
                { value: "moreThan5", label: "More than 5 years" },
                { value: "other", label: "Other" },
              ]}
              value={moveTime}
              onChange={setMoveTime}
            />
            <RadioGroupField
              label="Are you currently living in a 'Rented property' or 'Owned Property'?"
              id="propertyType"
              options={[
                { value: "rented", label: "Rented Property" },
                { value: "owned", label: "Owned Property" },
                { value: "other", label: "Other" },
              ]}
              value={propertyType}
              onChange={setPropertyType}
            />
            <RadioGroupField
              label="How frequently do you checkout properties to move on rent or purchase?"
              id="checkoutFrequency"
              options={[
                { value: "every6Months", label: "Every 6 Months" },
                { value: "6-12Months", label: "6-12 Months" },
                { value: "1-2years", label: "1-2 years" },
                { value: "2-4years", label: "2-4 years" },
                { value: "5+years", label: "5+ years" },
                { value: "other", label: "Other" },
              ]}
              value={checkoutFrequency}
              onChange={setCheckoutFrequency}
            />
          </div>
        );
      case 3:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold mb-6">Property Preferences</h2>
            <RadioGroupField
              label="Hypothetically, which of the below statements will best describe your next move?"
              id="nextMove"
              options={[
                { value: "rentedPlace", label: "I may Move to another rented place" },
                { value: "purchaseProperty", label: "I may Purchase a property to move in or as investment" },
                { value: "purchaseLand", label: "I may Purchase a plot/land in or around HYDERABAD while staying at my current home" },
                { value: "other", label: "Other" },
              ]}
              value={nextMove}
              onChange={setNextMove}
              required
            />
            <RadioGroupField
              label="What type of property are you looking or would you be looking for?"
              id="propertyLooking"
              options={[
                { value: "apartment", label: "Apartment" },
                { value: "villa", label: "Villa / House" },
                { value: "plot", label: "Plot/Land" },
                { value: "other", label: "Other" },
              ]}
              value={propertyLooking}
              onChange={setPropertyLooking}
              required
            />
            <SelectField
              label="If Rent - Budget Preferences?"
              id="rentBudget"
              options={[
                { value: "below40k", label: "Below ₹40,000" },
                { value: "40k-60k", label: "₹40,000 – ₹60,000" },
                { value: "above60k", label: "Above ₹ 60,000" },
                { value: "na", label: "Not Applicable" },
                { value: "other", label: "Other" },
              ]}
              value={rentBudget}
              onChange={setRentBudget}
            />
            <SelectField
              label="If Purchase - Budget Preferences?"
              id="purchaseBudget"
              options={[
                { value: "below50L", label: "Below ₹50 Lakhs" },
                { value: "50L-1Cr", label: "₹50 Lakhs–₹1 Crore" },
                { value: "1Cr-3Cr", label: "₹1 Crore–₹3 Crore" },
                { value: "above3Cr", label: "Above ₹3 Crore" },
                { value: "na", label: "Not Applicable" },
                { value: "other", label: "Other" },
              ]}
              value={purchaseBudget}
              onChange={setPurchaseBudget}
            />
            <RadioGroupField
              label="How long would you invest in searching for the right property, before making a decision?"
              id="searchDuration"
              options={[
                { value: "lessThan1Month", label: "Less than 1 month" },
                { value: "1-3months", label: "1-3 months" },
                { value: "moreThan3months", label: "More than 3 months" },
                { value: "other", label: "Other" },
              ]}
              value={searchDuration}
              onChange={setSearchDuration}
            />
            <RadioGroupField
              label="On average, how many properties do you plan visit in a week while searching actively?"
              id="weeklyVisits"
              options={[
                { value: "lessThan5", label: "Less than 5 properties" },
                { value: "5-10", label: "5-10 properties" },
                { value: "moreThan10", label: "More than 10 properties" },
                { value: "other", label: "Other" },
              ]}
              value={weeklyVisits}
              onChange={setWeeklyVisits}
            />
            <RadioGroupField
              label="How much of your time goes into researching, contacting owners/agents, and preparing action plans?"
              id="researchTime"
              options={[
                { value: "lessThan1Hour", label: "Less than 1 hour" },
                { value: "1-2Hours", label: "1-2 Hours" },
                { value: "moreThan2Hours", label: "More than 2 Hours" },
                { value: "other", label: "Other" },
              ]}
              value={researchTime}
              onChange={setResearchTime}
            />
            <RadioGroupField
              label="What is your mode of transport to visit the properties of interest?"
              id="transportMode"
              options={[
                { value: "ownCar", label: "Own Car" },
                { value: "ownBike", label: "Own Bike" },
                { value: "cabs", label: "Cabs (Uber/Ola/Rapido etc.)" },
                { value: "shareRide", label: "Share ride with friends/colleagues/family" },
              ]}
              value={transportMode}
              onChange={setTransportMode}
            />
            <RadioGroupField
              label="How much of your time goes into travelling to potential properties in a week?"
              id="travelTime"
              options={[
                { value: "lessThan2Hours", label: "Less than 2 Hours" },
                { value: "2-4Hours", label: "2-4 Hours" },
                { value: "4-8Hours", label: "4-8 Hours" },
                { value: "8-12Hours", label: "8-12 hours" },
                { value: "other", label: "Other" },
              ]}
              value={travelTime}
              onChange={setTravelTime}
            />
            <RadioGroupField
              label="What is your average spend per week on traveling to potential properties?"
              id="weeklySpend"
              options={[
                { value: "below1000", label: "Below ₹1000" },
                { value: "1000-3000", label: "₹1000 - ₹3000" },
                { value: "above3000", label: "Above ₹3000" },
              ]}
              value={weeklySpend}
              onChange={setWeeklySpend}
            />
            <div className="mb-4">
              <Label className="mb-1 block">
                How effective would you rate your outcome when compared to the time and resources invested?
              </Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((rating) => (
                  <Button
                    key={rating}
                    type="button"
                    variant={satisfaction === rating.toString() ? "default" : "outline"}
                    className={`w-10 h-10 p-0 ${satisfaction === rating.toString() ? "bg-bhoomer-primary" : ""}`}
                    onClick={() => setSatisfaction(rating.toString())}
                  >
                    {rating}
                  </Button>
                ))}
              </div>
              <div className="flex justify-between mt-2 text-sm text-gray-500">
                <span>Unsatisfactory Outcome</span>
                <span>Very Satisfied</span>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-grow py-10 px-4 md:px-10 bg-gray-50">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-bhoomer-primary mb-3">Join Our Waitlist</h1>
              <p className="text-gray-600">
                Complete this form to be among the first to experience Bhoomer
              </p>
            </div>
            
            <Card className="p-6 md:p-8 bg-white shadow-md">
              <FormProgressBar currentStep={step} totalSteps={totalSteps} />
              
              <div className="mt-8">
                {renderFormStep()}
                
                <div className="flex justify-between mt-8">
                  {step > 1 ? (
                    <Button type="button" variant="outline" onClick={prevStep}>
                      Back
                    </Button>
                  ) : (
                    <Button type="button" variant="outline" asChild>
                      <Link to="/">Cancel</Link>
                    </Button>
                  )}
                  
                  <Button type="button" onClick={nextStep}>
                    {step === totalSteps ? "Submit" : "Continue"}
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default WaitlistForm;
