
import React, { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { InputField, RadioGroupField, SelectField, CheckboxField } from "@/components/FormInputs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, Clock } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

const BookingPage = () => {
  const { toast } = useToast();

  // Booking details
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [numPeople, setNumPeople] = useState("");
  const [numSeats, setNumSeats] = useState("");
  const [carpooling, setCarpooling] = useState("");
  const [pickupLocation, setPickupLocation] = useState("");
  const [agreeToTerms, setAgreeToTerms] = useState(false);

  // Helper for time select options
  const generateTimeOptions = () => {
    const times = [];
    for (let hour = 9; hour <= 18; hour++) {
      const hourStr = hour > 12 ? hour - 12 : hour;
      const period = hour >= 12 ? "PM" : "AM";
      times.push({ value: `${hour}:00`, label: `${hourStr}:00 ${period}` });
      times.push({ value: `${hour}:30`, label: `${hourStr}:30 ${period}` });
    }
    return times;
  };

  const timeOptions = generateTimeOptions();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!date) {
      toast({
        title: "Please select a date",
        variant: "destructive",
      });
      return;
    }

    if (!startTime || !endTime) {
      toast({
        title: "Please select both start and end times",
        variant: "destructive",
      });
      return;
    }

    if (!numPeople) {
      toast({
        title: "Please specify number of people",
        variant: "destructive",
      });
      return;
    }

    if (!numSeats) {
      toast({
        title: "Please select number of seats",
        variant: "destructive",
      });
      return;
    }

    if (!carpooling) {
      toast({
        title: "Please indicate your carpooling preference",
        variant: "destructive",
      });
      return;
    }

    if (!pickupLocation.trim()) {
      toast({
        title: "Please enter your pickup location",
        variant: "destructive",
      });
      return;
    }

    if (!agreeToTerms) {
      toast({
        title: "Please agree to the terms and conditions",
        variant: "destructive",
      });
      return;
    }

    // In a real app, you'd submit the booking data to your backend here
    console.log({
      date,
      startTime,
      endTime,
      numPeople,
      numSeats,
      carpooling,
      pickupLocation,
      agreeToTerms,
    });

    // Show success toast
    toast({
      title: "Booking Successful!",
      description: "Your property visit has been scheduled. Check your email for confirmation.",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-grow py-10 px-4 md:px-10 bg-gray-50">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-bhoomer-primary mb-3">Schedule Your Property Visit</h1>
              <p className="text-gray-600">
                Book a convenient time for visiting properties with transportation included
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <Card className="shadow-md">
                  <CardHeader>
                    <CardTitle>Booking Details</CardTitle>
                    <CardDescription>
                      Fill in the details below to schedule your property visit
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-5">
                      <div>
                        <label className="block text-sm font-medium mb-1">Visit Date</label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !date && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {date ? format(date, "PPP") : "Select a date"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={date}
                              onSelect={setDate}
                              initialFocus
                              disabled={(date) => {
                                // Disable dates in the past
                                return date < new Date(new Date().setHours(0, 0, 0, 0));
                              }}
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <SelectField
                          label="Start Time"
                          id="startTime"
                          options={timeOptions}
                          value={startTime}
                          onChange={setStartTime}
                          placeholder="Select start time"
                          required
                        />
                        <SelectField
                          label="End Time"
                          id="endTime"
                          options={timeOptions.filter((time) => time.value > startTime)}
                          value={endTime}
                          onChange={setEndTime}
                          placeholder="Select end time"
                          required
                          
                        />
                      </div>

                      <SelectField
                        label="Number of People Visiting"
                        id="numPeople"
                        options={[
                          { value: "1", label: "1 person" },
                          { value: "2", label: "2 people" },
                          { value: "3", label: "3 people" },
                          { value: "4", label: "4 people" },
                          { value: "5plus", label: "5+ people" },
                        ]}
                        value={numPeople}
                        onChange={setNumPeople}
                        required
                      />

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-semibold text-bhoomer-primary mb-3">Cab Booking Options</h3>
                        
                        <SelectField
                          label="Number of Seats"
                          id="numSeats"
                          options={[
                            { value: "2", label: "2 seats" },
                            { value: "4", label: "4 seats" },
                            { value: "6", label: "6 seats" },
                          ]}
                          value={numSeats}
                          onChange={setNumSeats}
                          required
                        />
                        
                        <RadioGroupField
                          label="Would you like to carpool with other visitors?"
                          id="carpooling"
                          options={[
                            { value: "yes", label: "Yes, I am open to carpooling (reduced fare)" },
                            { value: "no", label: "No, I prefer a private cab" },
                          ]}
                          value={carpooling}
                          onChange={setCarpooling}
                          required
                        />
                        
                        <InputField
                          label="Pickup & Drop-off Location"
                          type="text"
                          id="pickupLocation"
                          placeholder="Enter your address"
                          value={pickupLocation}
                          onChange={(e) => setPickupLocation(e.target.value)}
                          required
                        />
                      </div>

                      <CheckboxField
                        label="I agree to the terms and conditions"
                        id="agreeToTerms"
                        checked={agreeToTerms}
                        onChange={setAgreeToTerms}
                      />

                      <Button type="submit" className="w-full">
                        Confirm Booking
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card className="shadow-md">
                  <CardHeader>
                    <CardTitle>Booking Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium text-sm text-gray-500">Date & Time</h4>
                      <p className="font-medium">
                        {date ? format(date, "PPP") : "Not selected"} <br />
                        {startTime && endTime ? 
                          `${startTime} - ${endTime}` : 
                          "Time not selected"}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-medium text-sm text-gray-500">People Visiting</h4>
                      <p className="font-medium">
                        {numPeople ? 
                          numPeople === "5plus" ? "5+ people" : `${numPeople} ${Number(numPeople) === 1 ? 'person' : 'people'}` : 
                          "Not specified"}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-medium text-sm text-gray-500">Transportation</h4>
                      <p className="font-medium">
                        {numSeats ? `${numSeats} seater cab` : "Not selected"}
                        {carpooling && <span className="block text-sm">{carpooling === "yes" ? "Carpooling" : "Private cab"}</span>}
                      </p>
                    </div>

                    <div className="pt-2">
                      <div className="flex justify-between py-2 border-t">
                        <span className="font-semibold">Service Fee</span>
                        <span className="font-semibold">₹499</span>
                      </div>
                      <div className="flex justify-between py-2 border-t border-b">
                        <span className="font-semibold">Transportation</span>
                        <span className="font-semibold">₹{carpooling === "yes" ? "299" : "599"}</span>
                      </div>
                      <div className="flex justify-between py-2 mt-2">
                        <span className="font-bold">Total</span>
                        <span className="font-bold">₹{carpooling === "yes" ? "798" : "1,098"}</span>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-3 rounded-lg mt-2">
                      <h4 className="font-semibold text-sm text-blue-700">About Your Visit</h4>
                      <ul className="text-sm text-blue-600 mt-2 space-y-1">
                        <li>• Properties near your location will be prioritized</li>
                        <li>• An expert agent will accompany you</li>
                        <li>• Visits typically last 20-30 minutes per property</li>
                        <li>• Receive property details in advance via email</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default BookingPage;
